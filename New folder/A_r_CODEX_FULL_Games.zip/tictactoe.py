import tkinter as tk
from tkinter import messagebox
root=tk.Tk(); root.title("A.r CODEX - Tic Tac Toe"); root.configure(bg="#111827")
turn="X"; board=[""]*9; buttons=[]
def win(p):
    lines=[(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
    return any(all(board[i]==p for i in line) for line in lines)
def click(i):
    global turn
    if board[i]: return
    board[i]=turn; buttons[i].config(text=turn)
    if win(turn):
        messagebox.showinfo("Tic Tac Toe",f"{turn} wins!"); reset(); return
    if all(board):
        messagebox.showinfo("Tic Tac Toe","Draw!"); reset(); return
    turn="O" if turn=="X" else "X"
def reset():
    global turn,board
    turn="X"; board=[""]*9
    for b in buttons: b.config(text="")
for i in range(9):
    b=tk.Button(root,text="",font=("Arial",28,"bold"),width=4,height=2,command=lambda i=i:click(i))
    b.grid(row=i//3,column=i%3,padx=4,pady=4); buttons.append(b)
tk.Button(root,text="New Game",command=reset).grid(row=3,column=0,columnspan=3,pady=10)
root.mainloop()
