import tkinter as tk
root=tk.Tk(); root.title("A.r CODEX - Breakout")
c=tk.Canvas(root,width=700,height=500,bg="#111827",highlightthickness=0); c.pack()
p=[300,470,400,485]; ball=[340,440,360,460]; vx,vy=4,-4
bricks=[[x,y,x+60,y+20] for y in range(50,130,25) for x in range(30,670,70)]
def key(e):
    if e.keysym=="Left": p[0]=max(0,p[0]-30); p[2]=p[0]+100
    if e.keysym=="Right": p[0]=min(600,p[0]+30); p[2]=p[0]+100
def loop():
    global vx,vy
    ball[0]+=vx; ball[1]+=vy
    if ball[0]<=0 or ball[2]>=700: vx=-vx
    if ball[1]<=0: vy=-vy
    if ball[3]>=p[1] and ball[0]<p[2] and ball[2]>p[0]: vy=-abs(vy)
    for b in bricks[:]:
        if ball[2]>b[0] and ball[0]<b[2] and ball[3]>b[1] and ball[1]<b[3]:
            bricks.remove(b); vy=-vy; break
    c.delete("all"); c.create_rectangle(*p,fill="white"); c.create_oval(*ball,fill="#22c55e")
    for b in bricks:c.create_rectangle(*b,fill="#f97316",outline="")
    if ball[3]>500 or not bricks:
        c.create_text(350,250,text="YOU WIN!" if not bricks else "GAME OVER",fill="white",font=("Arial",28,"bold")); return
    root.after(16,loop)
root.bind("<KeyPress>",key); loop(); root.mainloop()
