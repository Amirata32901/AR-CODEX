import tkinter as tk, random
N=9; MINES=10; root=tk.Tk(); root.title("A.r CODEX - Minesweeper")
mines=set(random.sample(range(N*N),MINES)); opened=set(); buttons=[]
def count(i):
    r,c=divmod(i,N); return sum((r+dr)*N+c+dc in mines for dr in(-1,0,1) for dc in(-1,0,1) if 0<=r+dr<N and 0<=c+dc<N and not(dr==dc==0))
def open_cell(i):
    if i in opened:return
    if i in mines:
        buttons[i].config(text="X"); return
    opened.add(i); n=count(i); buttons[i].config(text=str(n) if n else "")
    if n==0:
        r,c=divmod(i,N)
        for dr in(-1,0,1):
            for dc in(-1,0,1):
                rr,cc=r+dr,c+dc
                if 0<=rr<N and 0<=cc<N: open_cell(rr*N+cc)
for i in range(N*N):
    b=tk.Button(root,text="",width=3,height=1,font=("Arial",14),command=lambda i=i:open_cell(i))
    b.grid(row=i//N,column=i%N); buttons.append(b)
root.mainloop()
