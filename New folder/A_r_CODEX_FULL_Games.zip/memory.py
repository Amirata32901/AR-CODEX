import tkinter as tk, random
root=tk.Tk(); root.title("A.r CODEX - Memory")
symbols=list("AABBCCDDEEFFGGHH"); random.shuffle(symbols); first=None; lock=False; buttons=[]
def click(i):
    global first,lock
    if lock or buttons[i]["text"]: return
    buttons[i]["text"]=symbols[i]
    if first is None: first=i; return
    if symbols[first]==symbols[i]: first=None
    else:
        lock=True; a,b=first,i
        root.after(600,lambda:hide(a,b))
def hide(a,b):
    global first,lock
    buttons[a]["text"]=""; buttons[b]["text"]=""; first=None; lock=False
for i in range(16):
    b=tk.Button(root,text="",font=("Arial",20,"bold"),width=5,height=2,command=lambda i=i:click(i))
    b.grid(row=i//4,column=i%4,padx=3,pady=3); buttons.append(b)
root.mainloop()
