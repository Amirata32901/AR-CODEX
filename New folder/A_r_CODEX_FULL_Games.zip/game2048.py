import tkinter as tk, random
root=tk.Tk(); root.title("A.r CODEX - 2048"); grid=[[0]*4 for _ in range(4)]; labels=[]
def add():
    empty=[(r,c) for r in range(4) for c in range(4) if not grid[r][c]]
    if empty:
        r,c=random.choice(empty); grid[r][c]=2 if random.random()<.9 else 4
def move(e):
    if e.keysym not in ("Left","Right","Up","Down"): return
    old=[row[:] for row in grid]
    lines=[]
    for c in range(4): lines.append([grid[r][c] for r in range(4)])
    if e.keysym in ("Left","Right"):
        lines=[grid[r][:] for r in range(4)]
    for i,line in enumerate(lines):
        if e.keysym in ("Right","Down"): line=line[::-1]
        line=[x for x in line if x]
        out=[]
        while line:
            a=line.pop(0)
            if line and line[0]==a: line.pop(0); out.append(a*2)
            else: out.append(a)
        out += [0]*(4-len(out)); lines[i]=out[::-1] if e.keysym in ("Right","Down") else out
    if e.keysym in ("Left","Right"):
        for r in range(4): grid[r]=lines[r]
    else:
        for c in range(4):
            for r in range(4): grid[r][c]=lines[c][r]
    if grid!=old:add(); draw()
def draw():
    for r in range(4):
        for c in range(4): labels[r][c].config(text=str(grid[r][c]) if grid[r][c] else "")
for r in range(4):
    row=[]
    for c in range(4):
        l=tk.Label(root,text="",width=6,height=3,font=("Arial",18,"bold"),relief="ridge"); l.grid(row=r,column=c,padx=2,pady=2); row.append(l)
    labels.append(row)
add(); add(); draw(); root.bind("<KeyPress>",move); root.mainloop()
