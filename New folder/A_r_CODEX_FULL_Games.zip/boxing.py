import tkinter as tk
root=tk.Tk(); root.title("A.r CODEX - Boxing")
c=tk.Canvas(root,width=800,height=500,bg="#172033",highlightthickness=0); c.pack()
player_hp=100; enemy_hp=100; punch=False
def attack():
    global enemy_hp
    enemy_hp=max(0,enemy_hp-10); draw()
def enemy():
    global player_hp
    if enemy_hp>0: player_hp=max(0,player_hp-5); draw(); root.after(900,enemy)
def draw():
    c.delete("all"); c.create_text(400,30,text=f"YOU  {player_hp}     CPU  {enemy_hp}",fill="white",font=("Arial",22,"bold"))
    c.create_rectangle(170,180,300,400,fill="#38bdf8"); c.create_oval(185,110,285,210,fill="#f1c27d")
    c.create_rectangle(500,180,630,400,fill="#ef4444"); c.create_oval(515,110,615,210,fill="#f1c27d")
    if player_hp==0 or enemy_hp==0:c.create_text(400,250,text="YOU WIN!" if enemy_hp==0 else "YOU LOSE",fill="white",font=("Arial",32,"bold"))
tk.Button(root,text="PUNCH",font=("Arial",18,"bold"),command=attack).pack(pady=10)
draw(); root.after(900,enemy); root.mainloop()
