import tkinter as tk, random
root=tk.Tk(); root.title("A.r CODEX - Space Shooter")
c=tk.Canvas(root,width=700,height=500,bg="#050816",highlightthickness=0); c.pack()
ship=[330,440,370,470]; bullets=[]; enemies=[]; score=0
def key(e):
    if e.keysym=="Left": ship[0]=max(0,ship[0]-25); ship[2]=ship[0]+40
    if e.keysym=="Right": ship[0]=min(660,ship[0]+25); ship[2]=ship[0]+40
    if e.keysym=="space": bullets.append([ship[0]+18,ship[1]-12,ship[0]+22,ship[1]])
def loop():
    global score
    if random.random()<.035: x=random.randint(10,680); enemies.append([x,30,x+25,55])
    for b in bullets[:]: b[1]-=8; b[3]-=8; (bullets.remove(b) if b[3]<0 else None)
    for en in enemies[:]:
        en[1]+=3; en[3]+=3
        if en[3]>500: enemies.remove(en); continue
        for bu in bullets[:]:
            if bu[2]>en[0] and bu[0]<en[2] and bu[3]>en[1] and bu[1]<en[3]:
                bullets.remove(bu); enemies.remove(en); score+=1; break
    c.delete("all"); c.create_text(50,20,text=f"Score: {score}",fill="white")
    c.create_polygon(ship[0],ship[3],ship[2],ship[3],ship[0]+20,ship[1],fill="#38bdf8")
    for b in bullets:c.create_rectangle(*b,fill="#facc15")
    for en in enemies:c.create_oval(*en,fill="#ef4444")
    root.after(20,loop)
root.bind("<KeyPress>",key); loop(); root.mainloop()
