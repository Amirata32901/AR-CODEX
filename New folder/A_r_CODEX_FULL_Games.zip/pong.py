import tkinter as tk
root=tk.Tk(); root.title("A.r CODEX - Pong")
c=tk.Canvas(root,width=700,height=450,bg="#0b1020",highlightthickness=0); c.pack()
p1=[30,190,45,260]; p2=[655,190,670,260]; ball=[345,220,365,240]; vx,vy=5,3; score1=score2=0
def keys(e):
    if e.keysym=="w": p1[1]=max(0,p1[1]-25); p1[3]=p1[1]+70
    if e.keysym=="s": p1[1]=min(380,p1[1]+25); p1[3]=p1[1]+70
def loop():
    global vx,vy,score1,score2
    ball[0]+=vx; ball[1]+=vy
    if ball[1]<=0 or ball[3]>=450: vy=-vy
    if ball[0]<=p1[2] and p1[1]<ball[3] and p1[3]>ball[1]: vx=abs(vx)
    if ball[2]>=p2[0] and p2[1]<ball[3] and p2[3]>ball[1]: vx=-abs(vx)
    if ball[2]<0: score2+=1; ball[:]=[345,220,365,240]
    if ball[0]>700: score1+=1; ball[:]=[345,220,365,240]
    # simple AI
    center=(ball[1]+ball[3])/2
    if center> (p2[1]+35): p2[1]=min(380,p2[1]+5)
    elif center<(p2[1]+35): p2[1]=max(0,p2[1]-5)
    p2[3]=p2[1]+70
    c.delete("all"); c.create_text(350,25,text=f"{score1}    {score2}",fill="white",font=("Arial",22,"bold"))
    c.create_rectangle(*p1,fill="white"); c.create_rectangle(*p2,fill="white"); c.create_oval(*ball,fill="#22c55e")
    root.after(16,loop)
root.bind("<KeyPress>",keys); loop(); root.mainloop()
