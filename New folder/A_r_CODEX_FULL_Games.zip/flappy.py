import tkinter as tk, random
root=tk.Tk(); root.title("A.r CODEX - Flappy")
c=tk.Canvas(root,width=600,height=500,bg="#87ceeb",highlightthickness=0); c.pack()
bird=[100,240,120,260]; vy=0; pipes=[]; score=0
def flap(e=None):
    global vy
    vy=-8
root.bind("<space>",flap)
def add_pipe():
    gap=150; top=random.randint(80,330)
    pipes.append([600,0,630,top]); pipes.append([600,top+gap,630,500])
def loop():
    global vy,score
    vy+=0.45; bird[1]+=vy; bird[3]+=vy
    if not pipes or pipes[-1][0]<380: add_pipe()
    for p in pipes: p[0]-=3; p[2]-=3
    if pipes and pipes[0][2]<0: pipes.pop(0); score+=1
    hit=bird[1]<0 or bird[3]>500 or any(bird[2]>p[0] and bird[0]<p[2] and bird[3]>p[1] and bird[1]<p[3] for p in pipes)
    c.delete("all"); c.create_text(50,20,text=f"Score: {score}",fill="white",font=("Arial",14,"bold"))
    for p in pipes:c.create_rectangle(*p,fill="#16a34a",outline="")
    c.create_oval(*bird,fill="#facc15")
    if hit:
        c.create_text(300,250,text=f"GAME OVER  Score: {score}",font=("Arial",24,"bold"),fill="white"); return
    root.after(20,loop)
add_pipe(); loop(); root.mainloop()
