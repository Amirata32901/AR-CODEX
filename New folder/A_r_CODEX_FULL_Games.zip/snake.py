import tkinter as tk
import random

W,H,CELL=600,420,20
root=tk.Tk(); root.title("A.r CODEX - Snake"); root.resizable(False,False)
canvas=tk.Canvas(root,width=W,height=H,bg="#111827",highlightthickness=0); canvas.pack()
snake=[(300,200),(280,200),(260,200)]
direction="Right"; next_dir="Right"; score=0
food=(400,200)

def place_food():
    global food
    while True:
        p=(random.randrange(0,W,CELL),random.randrange(0,H,CELL))
        if p not in snake:
            food=p; break

def key(e):
    global next_dir
    m={"Up":"Down","Down":"Up","Left":"Right","Right":"Left"}
    if e.keysym in m and m[e.keysym]!=direction: next_dir=e.keysym

def tick():
    global snake,direction,score
    direction=next_dir
    x,y=snake[0]; dx,dy={"Up":(0,-CELL),"Down":(0,CELL),"Left":(-CELL,0),"Right":(CELL,0)}[direction]
    head=(x+dx,y+dy)
    if head[0]<0 or head[0]>=W or head[1]<0 or head[1]>=H or head in snake:
        canvas.create_text(W/2,H/2,text=f"GAME OVER  |  Score: {score}",fill="white",font=("Arial",26,"bold"))
        return
    snake.insert(0,head)
    if head==food:
        score+=1; place_food()
    else: snake.pop()
    draw(); root.after(90,tick)

def draw():
    canvas.delete("all")
    canvas.create_text(55,15,text=f"Score: {score}",fill="white",font=("Arial",12,"bold"))
    fx,fy=food; canvas.create_rectangle(fx,fy,fx+CELL,fy+CELL,fill="#ef4444",outline="")
    for i,(x,y) in enumerate(snake):
        canvas.create_rectangle(x,y,x+CELL,y+CELL,fill="#22c55e" if i else "#86efac",outline="#111827")

root.bind("<KeyPress>",key); place_food(); draw(); root.after(500,tick); root.mainloop()
